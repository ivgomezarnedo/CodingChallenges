from interfaces.output_interface import OutputInterface


class DynamoDBOutputAdapter(OutputInterface):
    # To be implemented

    def output_data(self, data):
        raise NotImplementedError()
