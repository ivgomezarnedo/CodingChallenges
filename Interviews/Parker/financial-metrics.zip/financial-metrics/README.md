## Goal
Design a system for calculating financial business metrics for e-commerce businesses, from data obtained via third-party API integration.  

## Requirements
#### Documentation
Write a design document with enough details that someone other than yourself can follow and implement

Example areas of focus:
- Storage design, schema, type of storage, etc.
- System design, storage, pipeline, method of integration with third-party API, interface for retrieving metrics, etc.

We understand your time is valuable, so feel free to omit low-level details that you think are trivial, but the high level design shall be clear.  List assumptions you make.  Also there is no need to re-invent; feel free to use any actually available technology you think fits, with a quick description on why and how the technology helps.
#### Implementation
Implement the system that processes and loads the example payloads to the next system

You should focus on the design first and then work on this section last; we don't want this requirement to influence your design decision.  
We are only looking for the implementation of the immediate system that processes and loads the example JSON payloads; everything before and after that is not required.
We expect you to be able to set up a simple but testable environment for this. 
Depending on the complexity of your design, this, entirely or partially, could be optional but shall be reasonably justified.  Feel free to contact us to discuss this.

## Contexts
#### Third-party APIs
You are given API access to fetch data from the 2 following unrelated SaaS platforms.  One platform provides service to businesses for storing their "profit and loss" data, while the other platform is used for storing "balance sheet" data.  For simplicity, you can assume:
- all businesses use both platforms, 
- each business has a globally-unique "business identifier"
- the unique ID identifies the same businesses on both platforms. 

_SaaS API for Profit and Loss_
- /business/{businessId}/profit_Loss
  - example payload: profit_loss.json
  - returns all monthly data for the business, "updatedAt" field in each monthly payload changes only if the data has been updated for that month in third-party system

_SaaS API for Balance Sheet_
- /business/{businessId}/monthly_balance_sheet?date={yyyy-mm}
  - example payload: balance_sheet.json
  - returns data for the business for the month specified in the query param, "updatedAt" changes only if the data has been updated in third-party system

#### Business Requirements
- The system shall be able to calculate metrics for 10K, and increasing, businesses
- Metrics shall not be stale longer than 24 hours for all businesses, if new/updated data is available, i.e. if we look at the metrics for a business now, the metrics shall be based on the latest data made available by the third-party API within the last 24 hours
- Be able to see break-down of all secondary category of things, e.g. for balance_sheet assets, we need to be able to see and filter "Fixed Assets" and "Current Assets", same for profit_loss expenses, "Advertising & Marketing", "General Expenses", etc.
- For profit_loss, we need the following financial metrics for any given business for high-read use case:
  - income, costOfSales, expenses, gross_profit (income-costOfSales), net_profit (gross_profit-expenses), and profit_margin (net_profit/income) for below conditions
    - current month
    - last 3 month avg (not counting current month)
    - last 3 month avg change year-over-year (e.g. `(last 3 month avg of income)/(last 3 month avg of income from a year ago)`)
- For another high-read use case we need for a given business:
  - `Current month liabilities("Current Liabilities" only, ignore "Other Liabilities") / sum of income of last 12 months`
